﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Diagnostics;
using System;

public class Calculator : MonoBehaviour
{

    public InputField MoneyInput;
    public Text MoneyOutput;

    public Toggle USD;
    public Toggle RM;
    public Toggle Yen;

    float Money;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Convert()
    {

        try
        {
            Money = float.Parse(MoneyInput.text);
        }
        catch (FormatException)
        {
            MoneyInput.text = "";
        }

        MoneyOutput.text = "";        

        if (USD.GetComponent<Toggle>().isOn == true)
        {
            Money *= 0.74f;
        }
        else if (RM.GetComponent<Toggle>().isOn == true)
        {
            Money *= 3.42f;
        }
        else if (Yen.GetComponent<Toggle>().isOn == true)
        {
            Money *= 82.78f;
        }

        MoneyOutput.text = Money.ToString();
    }

    public void Clear()
    {
        MoneyInput.text = "";
        MoneyOutput.text = "";
        RM.GetComponent<Toggle>().isOn = false;
        Yen.GetComponent<Toggle>().isOn = false;
        USD.GetComponent<Toggle>().isOn = false;
    }

    public void ClearUSD()
    {
        if (USD.GetComponent<Toggle>().isOn)
        {
            RM.GetComponent<Toggle>().isOn = false;
            Yen.GetComponent<Toggle>().isOn = false;
        }        
    }

    public void ClearRM()
    {
        if (RM.GetComponent<Toggle>().isOn)
        {
            USD.GetComponent<Toggle>().isOn = false;
            Yen.GetComponent<Toggle>().isOn = false;
        }
    }

    public void ClearYen()
    {
        if (Yen.GetComponent<Toggle>().isOn)
        {
            RM.GetComponent<Toggle>().isOn = false;
            USD.GetComponent<Toggle>().isOn = false;
        }
    }

}
